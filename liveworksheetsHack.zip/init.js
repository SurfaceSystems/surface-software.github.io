document.querySelectorAll(".adsbygoogle").forEach(ads => {ads.style.display = "none"});
document.getElementById("capaanuncio").style.display = "none";
document.querySelectorAll("[id='capaanuncio']").forEach(ad => {ad.style.display = "none"});
document.querySelectorAll("[data-google-query-id]").forEach(ad => {ad.style.display = "none"});
document.getElementById("div-gpt-ad-2415540-3").style.display = "none";
document.querySelectorAll("[data-google-query-id]").forEach(ads => {ads.style.display = "none"});
alert("Pulsa aceptar para eliminar los anuncios post-carga.");
document.querySelectorAll('[alt="Advertisement"]').forEach(ads => {ads.style.display = "none"});