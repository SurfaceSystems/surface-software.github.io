// BadSearchHider 1.0.0
// @author: Lite (LPache23)
// Lite Public NT x_14.01


let info1 = document.querySelectorAll("[class='MjjYud']");
info1.forEach(elem => {if(elem.innerText.includes("xxx")) {elem.style.display = "none"}})

let info2 = document.querySelectorAll("[class='MjjYud']");
info2.forEach(elem => {if(elem.innerText.includes("XXX")) {elem.style.display = "none"}})

let info3 = document.querySelectorAll("[class='MjjYud']");
info3.forEach(elem => {if(elem.innerText.includes("Xxx")) {elem.style.display = "none"}})

let info4 = document.querySelectorAll("[class='MjjYud']");
info4.forEach(elem => {if(elem.innerText.includes("xXx")) {elem.style.display = "none"}})

let info5 = document.querySelectorAll("[class='MjjYud']");
info5.forEach(elem => {if(elem.innerText.includes("xxX")) {elem.style.display = "none"}})

let info6 = document.querySelectorAll("[class='MjjYud']");
info6.forEach(elem => {if(elem.innerText.includes("XXx")) {elem.style.display = "none"}})

let info7 = document.querySelectorAll("[class='MjjYud']");
info7.forEach(elem => {if(elem.innerText.includes("xXX")) {elem.style.display = "none"}})

let info8 = document.querySelectorAll("[class='MjjYud']");
info8.forEach(elem => {if(elem.innerText.includes("XxX")) {elem.style.display = "none"}})