// LiteLiveWorksheets Ad-Blocker 1.7.0
// @author: Lite (LPache23)
// Lite Public NT x_8.01 (Remastered 2021 - 2023)

try {
document.querySelectorAll(".adsbygoogle").forEach(ads => {ads.style.display = "none"});
document.getElementById("capaanuncio").style.display = "none";
document.querySelectorAll("[id='capaanuncio']").forEach(ad => {ad.style.display = "none"});
document.querySelectorAll("[data-google-query-id]").forEach(ad => {ad.style.display = "none"});
document.getElementById("div-gpt-ad-2415540-3").style.display = "none";
document.querySelectorAll("[data-google-query-id]").forEach(ads => {ads.style.display = "none"});
} catch (e) {
    document.getElementById("div-gpt-ad-2415540-3").style.display = "none";
document.querySelectorAll("[data-google-query-id]").forEach(ads => {ads.style.display = "none"});
document.querySelectorAll(".adsbygoogle").forEach(ads => {ads.style.display = "none"});
}
console.log("Thanks for using this ad-blocker, get updated with the last version in https://litech.w3spaces.com/lite-surface.html")